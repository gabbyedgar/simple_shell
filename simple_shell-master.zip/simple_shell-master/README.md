Simple shell project
